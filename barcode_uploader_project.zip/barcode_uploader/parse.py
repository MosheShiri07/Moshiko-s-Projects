import re
from typing import Optional

def parse_invoice_id(raw: str, prefix: str = "INV") -> Optional[str]:
    m = re.search(rf"{re.escape(prefix)}(\d+)", raw, re.IGNORECASE)
    if m:
        return m.group(1)
    return raw.strip()
