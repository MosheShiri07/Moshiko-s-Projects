import threading
import serial
from pynput import keyboard

class HIDCapture:
    def __init__(self, on_scan, terminator='\n'):
        self.on_scan = on_scan
        self.terminator = terminator
        self.buf = []
        self.listener = None

    def _on_press(self, key):
        try:
            ch = key.char
        except:
            ch = None
        if ch:
            if ch == self.terminator:
                text = ''.join(self.buf).strip()
                self.buf = []
                if text:
                    self.on_scan(text)
            else:
                self.buf.append(ch)
        elif key == keyboard.Key.enter:
            text = ''.join(self.buf).strip()
            self.buf = []
            if text:
                self.on_scan(text)

    def start(self):
        self.listener = keyboard.Listener(on_press=self._on_press)
        self.listener.start()

class SerialCapture(threading.Thread):
    def __init__(self, port, baudrate, on_scan):
        super().__init__(daemon=True)
        self.port = port
        self.baudrate = baudrate
        self.on_scan = on_scan
        self._stop = False

    def run(self):
        with serial.Serial(self.port, self.baudrate, timeout=1) as ser:
            buf = b''
            while not self._stop:
                if ser.in_waiting:
                    buf += ser.read(ser.in_waiting)
                    while b'\n' in buf:
                        line, buf = buf.split(b'\n', 1)
                        text = line.decode(errors='ignore').strip()
                        if text:
                            self.on_scan(text)

    def stop(self):
        self._stop = True
