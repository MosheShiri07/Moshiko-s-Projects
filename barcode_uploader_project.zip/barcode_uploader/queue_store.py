import sqlite3
import json
import threading

class SQLiteQueue:
    def __init__(self, path: str = "queue.db"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.lock = threading.Lock()
        with self.conn:
            self.conn.execute('''CREATE TABLE IF NOT EXISTS queue(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                payload TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )''')

    def push(self, payload):
        with self.lock, self.conn:
            self.conn.execute("INSERT INTO queue(payload) VALUES(?)", (json.dumps(payload),))

    def pop_batch(self, limit=50):
        with self.lock:
            cur = self.conn.cursor()
            cur.execute("SELECT id, payload FROM queue ORDER BY id ASC LIMIT ?", (limit,))
            rows = cur.fetchall()
        return [{"id": r[0], "payload": json.loads(r[1])} for r in rows]

    def delete_ids(self, ids):
        if not ids:
            return
        qmarks = ",".join("?" * len(ids))
        with self.lock, self.conn:
            self.conn.execute(f"DELETE FROM queue WHERE id IN ({qmarks})", ids)
