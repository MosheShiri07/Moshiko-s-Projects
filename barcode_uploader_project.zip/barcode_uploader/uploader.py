import os
import json
from datetime import datetime, timedelta, timezone
from google.cloud import bigquery
from google.oauth2 import service_account

IST_FIXED = timezone(timedelta(hours=2))

def creds_from_env() -> service_account.Credentials:
    b64 = os.environ.get("GOOGLE_CREDENTIALS_BASE64")
    if not b64:
        raise RuntimeError("Missing GOOGLE_CREDENTIALS_BASE64")
    import base64
    data = json.loads(base64.b64decode(b64))
    return service_account.Credentials.from_service_account_info(data, scopes=["https://www.googleapis.com/auth/bigquery"])

def get_meal_type(ts_utc: datetime) -> str:
    local = ts_utc.astimezone(IST_FIXED)
    return "breakfast" if local.hour < 11 else "lunch"

class BigQueryUploader:
    def __init__(self, cfg):
        self.cfg = cfg
        self.client = bigquery.Client(project=cfg["gcp_project_id"], credentials=creds_from_env())
        self.table_id = f'{cfg["gcp_project_id"]}.{cfg["dataset"]}.{cfg["table"]}'
        self.timeout = cfg.get("upload_timeout_seconds", 10)

    def upload(self, row):
        errors = self.client.insert_rows_json(self.table_id, [row], timeout=self.timeout)
        if errors:
            raise RuntimeError(str(errors))
