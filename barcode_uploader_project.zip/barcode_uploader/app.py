import json
import time
import socket
import getpass
from datetime import datetime, timezone, timedelta
from collections import OrderedDict
import threading

from parse import parse_invoice_id
from uploader import BigQueryUploader, get_meal_type
from queue_store import SQLiteQueue
from capture import HIDCapture, SerialCapture
from ui import AppUI

class DuplicateGuard:
    def __init__(self, minutes):
        self.minutes = minutes
        self.last = OrderedDict()

    def allow(self, barcode, now):
        cutoff = now - timedelta(minutes=self.minutes)
        for k in list(self.last.keys()):
            if self.last[k] < cutoff:
                del self.last[k]
        ts = self.last.get(barcode)
        if ts and (now - ts).total_seconds() < self.minutes * 60:
            return False
        self.last[barcode] = now
        return True

def load_cfg():
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def main():
    cfg = load_cfg()
    dup = DuplicateGuard(cfg.get("duplicate_window_minutes", 4))
    ui = AppUI()
    ui.run_async()
    uploader = BigQueryUploader(cfg)
    queue = SQLiteQueue()

    def process_scan(raw_barcode):
        now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
        if not dup.allow(raw_barcode, now_utc):
            ui.set_status("Duplicate scan. Ignored")
            return
        invoice_id = parse_invoice_id(raw_barcode, cfg.get("invoice_prefix", "INV"))
        row = {
            "invoice_id": invoice_id,
            "raw_barcode": raw_barcode,
            "scanned_at": now_utc.isoformat().replace("+00:00", "Z"),
            "machine": socket.gethostname(),
            "username": getpass.getuser(),
            "meal_type": get_meal_type(now_utc)
        }
        try:
            uploader.upload(row)
            ui.set_status("Upload successful")
        except Exception:
            queue.push(row)
            ui.set_status("Upload failed. Queued")

    if cfg.get("hid_mode", True):
        HIDCapture(process_scan).start()
    else:
        SerialCapture(cfg["serial_port"], cfg.get("serial_baudrate", 9600), process_scan).start()

    def retry_worker():
        while True:
            batch = queue.pop_batch(50)
            if not batch:
                time.sleep(cfg.get("retry_interval_seconds", 30))
                continue
            succeeded = []
            for item in batch:
                try:
                    uploader.upload(item["payload"])
                    succeeded.append(item["id"])
                except Exception:
                    pass
            if succeeded:
                queue.delete_ids(succeeded)

    threading.Thread(target=retry_worker, daemon=True).start()

    while True:
        time.sleep(1)

if __name__ == "__main__":
    main()
