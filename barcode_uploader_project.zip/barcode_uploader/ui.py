import threading
import tkinter as tk

class AppUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Barcode Uploader")
        self.status = tk.StringVar(value="Ready")
        tk.Label(self.root, textvariable=self.status, font=("Segoe UI", 12)).pack(padx=12, pady=12)
        self.queue_size = tk.StringVar(value="Queue: 0")
        tk.Label(self.root, textvariable=self.queue_size).pack(padx=12, pady=(0,12))

    def set_status(self, text):
        self.status.set(text)
        self.root.update_idletasks()

    def set_queue(self, n):
        self.queue_size.set(f"Queue: {n}")
        self.root.update_idletasks()

    def run_async(self):
        threading.Thread(target=self.root.mainloop, daemon=True).start()
